// import logo from './../public/images/dev-blank.png';
const menu = document.querySelector('#menu');
const hero = document.querySelector('.content');
const main = document.querySelector('main');
const drawer = document.querySelector('#drawer');

menu.addEventListener('click', function (event) {
  drawer.classList.toggle('open');
//   drawer.style.display="block";
  event.stopPropagation();
});

hero.addEventListener('click', function () {
  drawer.classList.remove('open');
});

main.addEventListener('click', function () {
  drawer.classList.remove('open');
});
import 'regenerator-runtime'; /* for async await transpile */
import '../styles/main.css';

import data from '../DATA.json';

const listResto=document.getElementById("listResto");
let chtml=``;
data.restaurants.forEach((v,i) => {
    chtml+=`<div class='box'>
                <figure>
                    <img class="" src="${v.pictureId}" alt="profil restoran">
                </figure>
                <div class="title">
                    <a href="#" class="">${v.name}</a>
                    <figcaption>
                        <img style="max-width: 15px" src="images/star.webp" alt="chef resto"> <span>${v.rating}</span>
                    </figcaption>
                </div>
            </div>`;
});
listResto.innerHTML=chtml;
// console.log(data);
// console.log('Hello Coders! :)');

/* eslint-disable linebreak-style */
import FavoriteRestoIdb from '../../data/idb';
import CONFIG from '../../globals/config';

const pageFavorite = {
  async render() {
    // eslint-disable-next-line quotes
    return `<div id="listResto" class="wrapper">
    </div>`;
  },
  async afterRender() {
    const dt = await FavoriteRestoIdb.getAll();
    const listResto = document.getElementById('listResto');
    let chtml = '';
    dt.forEach((v) => {
      chtml += `<div class='box'>
                    <figure>
                        <img class="imgRadius" src="${CONFIG.BASE_IMAGE_URL + v.pictureId}" alt="profil restoran">
                    </figure>
                    <div class="title">
                      <div class="rating">
                        <span>⭐️${v.rating}</span>
                      </div>
                      <div class="nmResto">
                        <a href="${window.location.origin}/#/detail/${v.id}" class="">${v.name}</a>
                      </div>                        
                    </div>
                    <p>${v.description.substring(0, 100)}...</p>
                </div>`;
    });
    listResto.innerHTML = chtml;
  },
};
export default pageFavorite;
